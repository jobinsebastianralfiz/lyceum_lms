from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.middleware.csrf import get_token
from django.db.models import Q, Count, Avg
from django.core.paginator import Paginator
from django.utils import timezone
from apps.users.models import User
from apps.courses.models import Course, Category, Module, VideoLesson, StudentProgress, ModuleProgress
from apps.payments.models import Enrollment


@ensure_csrf_cookie
def student_login(request):
    """Student login page"""
    # Force CSRF cookie to be set
    get_token(request)
    
    # Check if already logged in
    if request.user.is_authenticated and hasattr(request.user, 'role') and request.user.role == 'student':
        return redirect('student_portal:dashboard')
    
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        if email and password:
            # Authenticate user
            user = authenticate(request, username=email, password=password)
            if user and hasattr(user, 'role') and user.role == 'student':
                # Create session if it doesn't exist
                if not request.session.session_key:
                    request.session.create()
                
                # Log the user in
                login(request, user)
                
                # Force session save
                request.session.save()
                
                messages.success(request, f'Welcome back, {user.name}!')
                
                # Get redirect URL
                next_url = request.POST.get('next') or request.GET.get('next')
                if next_url and next_url != request.path:
                    return redirect(next_url)
                else:
                    return redirect('student_portal:dashboard')
            else:
                messages.error(request, 'Invalid credentials or account not found.')
        else:
            messages.error(request, 'Please provide both email and password.')
    
    # Ensure CSRF token is available
    context = {
        'csrf_token': get_token(request)
    }
    return render(request, 'student_portal/auth/login.html', context)


def student_logout(request):
    """Student logout"""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('student_portal:login')


def dashboard(request):
    """Student dashboard"""
    # Check authentication and role
    if not request.user.is_authenticated:
        messages.error(request, 'Please login to access the student portal.')
        return redirect('student_portal:login')
    
    if not hasattr(request.user, 'role') or request.user.role != 'student':
        messages.error(request, 'Access denied. Student role required.')
        return redirect('student_portal:login')
    
    user = request.user
    
    # Get student's enrollments
    enrollments = Enrollment.objects.filter(
        user=user, 
        active=True
    ).select_related('course', 'course__category').order_by('-enrolled_on')
    
    # Calculate statistics
    total_courses = enrollments.count()
    completed_courses = 0
    in_progress_courses = 0
    
    for enrollment in enrollments:
        # Check if course is completed (simplified logic)
        total_modules = enrollment.course.modules.count()
        completed_modules = ModuleProgress.objects.filter(
            student=user,
            module__course=enrollment.course,
            is_completed=True
        ).count()
        
        if total_modules > 0 and completed_modules == total_modules:
            completed_courses += 1
        elif completed_modules > 0:
            in_progress_courses += 1
    
    # Recent activity
    recent_progress = StudentProgress.objects.filter(
        user=user
    ).select_related('video_lesson', 'course').order_by('-last_watched_at')[:5]
    
    context = {
        'user': user,
        'enrollments': enrollments[:6],  # Show first 6 courses
        'total_courses': total_courses,
        'completed_courses': completed_courses,
        'in_progress_courses': in_progress_courses,
        'recent_activity': recent_progress,
    }
    
    return render(request, 'student_portal/dashboard.html', context)


def my_courses(request):
    """List all student's enrolled courses"""
    if not request.user.is_authenticated:
        return redirect('student_portal:login')
    
    user = request.user
    
    # Get search and filter parameters
    search = request.GET.get('search', '')
    status = request.GET.get('status', 'all')  # all, in_progress, completed
    
    # Base queryset
    enrollments = Enrollment.objects.filter(
        user=user, 
        active=True
    ).select_related('course', 'course__category')
    
    # Apply search
    if search:
        enrollments = enrollments.filter(
            Q(course__title__icontains=search) |
            Q(course__description__icontains=search)
        )
    
    # Apply status filter
    if status == 'completed':
        # Filter completed courses (this would need more complex logic)
        pass
    elif status == 'in_progress':
        # Filter in-progress courses
        pass
    
    # Pagination
    paginator = Paginator(enrollments, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search': search,
        'status': status,
    }
    
    return render(request, 'student_portal/courses/my_courses.html', context)


def course_detail(request, course_id):
    """Course detail and learning interface"""
    if not request.user.is_authenticated:
        return redirect('student_portal:login')
    
    user = request.user
    course = get_object_or_404(Course, id=course_id, is_published=True)
    
    # Check if user is enrolled
    try:
        enrollment = Enrollment.objects.get(user=user, course=course, active=True)
    except Enrollment.DoesNotExist:
        messages.error(request, 'You are not enrolled in this course.')
        return redirect('student_portal:browse_courses')
    
    # Get modules with progress
    modules = course.modules.prefetch_related('video_lessons').order_by('order')
    
    # Get user's module progress
    module_progress = {}
    for module in modules:
        try:
            progress = ModuleProgress.objects.get(student=user, module=module)
            module_progress[module.id] = progress
        except ModuleProgress.DoesNotExist:
            # Create initial progress if doesn't exist
            progress = ModuleProgress.objects.create(
                student=user,
                module=module,
                is_unlocked=(module.order == 1)  # Unlock first module
            )
            module_progress[module.id] = progress
    
    context = {
        'course': course,
        'enrollment': enrollment,
        'modules': modules,
        'module_progress': module_progress,
    }
    
    return render(request, 'student_portal/courses/course_detail.html', context)


def lesson_viewer(request, lesson_id):
    """Video lesson viewer"""
    if not request.user.is_authenticated:
        return redirect('student_portal:login')
    
    user = request.user
    lesson = get_object_or_404(VideoLesson, id=lesson_id)
    
    # Check if user is enrolled in the course
    try:
        enrollment = Enrollment.objects.get(
            user=user, 
            course=lesson.module.course, 
            active=True
        )
    except Enrollment.DoesNotExist:
        messages.error(request, 'You are not enrolled in this course.')
        return redirect('student_portal:browse_courses')
    
    # Check if module is unlocked
    try:
        module_progress = ModuleProgress.objects.get(
            student=user, 
            module=lesson.module
        )
        if not module_progress.is_unlocked:
            messages.error(request, 'This module is not yet available.')
            return redirect('student_portal:course_detail', course_id=lesson.module.course.id)
    except ModuleProgress.DoesNotExist:
        messages.error(request, 'Module progress not found.')
        return redirect('student_portal:course_detail', course_id=lesson.module.course.id)
    
    # Get or create lesson progress
    progress, _ = StudentProgress.objects.get_or_create(
        user=user,
        course=lesson.module.course,
        video_lesson=lesson,
        defaults={'completed_percentage': 0.0}
    )
    
    # Get next and previous lessons
    current_module = lesson.module
    next_lesson = VideoLesson.objects.filter(
        module=current_module,
        order__gt=lesson.order
    ).order_by('order').first()
    
    prev_lesson = VideoLesson.objects.filter(
        module=current_module,
        order__lt=lesson.order
    ).order_by('-order').first()
    
    context = {
        'lesson': lesson,
        'progress': progress,
        'next_lesson': next_lesson,
        'prev_lesson': prev_lesson,
        'course': lesson.module.course,
        'module': current_module,
    }
    
    return render(request, 'student_portal/courses/lesson_viewer.html', context)


def browse_courses(request):
    """Browse available courses for enrollment"""
    # Get search and filter parameters
    search = request.GET.get('search', '')
    category_id = request.GET.get('category')
    is_free = request.GET.get('is_free')
    
    # Base queryset
    courses = Course.objects.filter(
        is_published=True,
        allow_public_enrollment=True
    ).select_related('category', 'created_by')
    
    # Apply filters
    if search:
        courses = courses.filter(
            Q(title__icontains=search) |
            Q(description__icontains=search)
        )
    
    if category_id:
        courses = courses.filter(category_id=category_id)
    
    if is_free == 'true':
        courses = courses.filter(is_free=True)
    elif is_free == 'false':
        courses = courses.filter(is_free=False)
    
    # Get categories for filter
    categories = Category.objects.all()
    
    # Pagination
    paginator = Paginator(courses, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'categories': categories,
        'search': search,
        'selected_category': category_id,
        'is_free': is_free,
    }
    
    return render(request, 'student_portal/courses/browse.html', context)


def profile(request):
    """Student profile page"""
    if not request.user.is_authenticated:
        return redirect('student_portal:login')
    
    user = request.user
    
    if request.method == 'POST':
        # Update profile
        user.name = request.POST.get('name', user.name)
        user.phone_number = request.POST.get('phone_number', user.phone_number)
        user.address = request.POST.get('address', user.address)
        user.save()
        
        messages.success(request, 'Profile updated successfully!')
        return redirect('student_portal:profile')
    
    # Get enrollment statistics
    enrollments = Enrollment.objects.filter(user=user, active=True)
    total_courses = enrollments.count()
    
    context = {
        'user': user,
        'total_courses': total_courses,
    }
    
    return render(request, 'student_portal/profile.html', context)


@require_http_methods(["POST"])
def update_lesson_progress(request, lesson_id):
    """AJAX endpoint to update lesson progress"""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required'}, status=401)
    
    user = request.user
    lesson = get_object_or_404(VideoLesson, id=lesson_id)
    
    # Check enrollment
    try:
        Enrollment.objects.get(
            user=user, 
            course=lesson.module.course, 
            active=True
        )
    except Enrollment.DoesNotExist:
        return JsonResponse({'error': 'Not enrolled'}, status=403)
    
    # Get progress data
    completed_percentage = float(request.POST.get('completed_percentage', 0))
    completed = request.POST.get('completed', 'false').lower() == 'true'
    
    # Update progress
    progress, created = StudentProgress.objects.get_or_create(
        user=user,
        course=lesson.module.course,
        video_lesson=lesson,
        defaults={
            'completed_percentage': completed_percentage,
            'completed': completed
        }
    )
    
    if not created:
        progress.completed_percentage = max(progress.completed_percentage, completed_percentage)
        progress.completed = completed or progress.completed
        progress.save()
    
    # Update module progress
    module_progress = ModuleProgress.objects.get(student=user, module=lesson.module)
    module_progress.check_completion()
    
    return JsonResponse({
        'success': True,
        'completed_percentage': progress.completed_percentage,
        'completed': progress.completed
    })
