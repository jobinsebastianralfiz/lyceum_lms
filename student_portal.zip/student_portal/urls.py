from django.urls import path
from . import views

app_name = 'student_portal'

urlpatterns = [
    # Authentication
    path('login/', views.student_login, name='login'),
    path('logout/', views.student_logout, name='logout'),
    
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Courses
    path('my-courses/', views.my_courses, name='my_courses'),
    path('browse/', views.browse_courses, name='browse_courses'),
    path('course/<int:course_id>/', views.course_detail, name='course_detail'),
    path('lesson/<int:lesson_id>/', views.lesson_viewer, name='lesson_viewer'),
    
    # Profile
    path('profile/', views.profile, name='profile'),
    
    # AJAX endpoints
    path('api/lesson/<int:lesson_id>/progress/', views.update_lesson_progress, name='update_lesson_progress'),
]