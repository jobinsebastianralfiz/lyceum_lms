import json
import razorpay
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model, authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.conf import settings
from django.db import transaction
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.utils import timezone
from django import forms

from apps.courses.models import Course, Category
from apps.payments.models import Enrollment, Payment

User = get_user_model()

# Custom registration form
class PublicUserRegistrationForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your email'
        })
    )
    name = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your full name'
        })
    )
    phone = forms.CharField(
        max_length=15,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your phone number (optional)'
        })
    )
    
    class Meta:
        model = User
        fields = ('username', 'name', 'email', 'phone', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Choose a username'
            })
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Create a password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm your password'
        })
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("A user with this email already exists.")
        return email
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.name = self.cleaned_data['name']
        if self.cleaned_data.get('phone'):
            user.phone = self.cleaned_data['phone']
        if commit:
            user.save()
        return user


def home(request):
    """Landing page view with featured courses"""
    courses = Course.objects.filter(
        is_published=True, 
        allow_public_enrollment=True
    ).order_by('-created_at')[:6]  # Get featured courses
    
    context = {
        'courses': courses,
    }
    return render(request, 'landing/home.html', context)

def privacy_policy(request):
    """Privacy policy page view"""
    return render(request, 'landing/privacy_policy.html')

def terms_conditions(request):
    """Terms and conditions page view"""
    return render(request, 'landing/terms_conditions.html')

def register(request):
    """Public user registration with email verification"""
    if request.user.is_authenticated:
        return redirect('landing:home')
    
    if request.method == 'POST':
        # Handle form data manually for new template
        email = request.POST.get('email')
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        phone = request.POST.get('phone', '')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        
        # Basic validation
        if not all([email, first_name, password1, password2]):
            messages.error(request, 'Please fill in all required fields.')
            return render(request, 'landing/register.html')
        
        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'landing/register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'A user with this email already exists.')
            return render(request, 'landing/register.html')
        
        try:
            # Create user
            username = email.split('@')[0]  # Use email prefix as username
            counter = 1
            original_username = username
            while User.objects.filter(username=username).exists():
                username = f"{original_username}{counter}"
                counter += 1
            
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password1,
                name=f"{first_name} {last_name}".strip(),
                phone=phone
            )
            
            # Send verification email
            from emails.utils import send_verification_email
            try:
                if send_verification_email(user):
                    messages.success(request, f'Account created successfully! Please check your email to verify your account before logging in.')
                else:
                    messages.warning(request, f'Account created successfully! However, there was an issue sending the verification email. You can still log in.')
            except Exception as e:
                messages.warning(request, f'Account created successfully! There was an issue sending the verification email, but you can still log in.')
            
            return redirect('landing:login')
            
        except Exception as e:
            messages.error(request, f'Error creating account: {str(e)}')
    
    return render(request, 'landing/register.html')


def login_view(request):
    """User login view"""
    if request.user.is_authenticated:
        # Redirect authenticated users to appropriate dashboard
        if request.user.is_staff:
            return redirect('custom_admin:dashboard')
        else:
            return redirect('student_portal:dashboard')
    
    if request.method == 'POST':
        email_or_username = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        
        if not email_or_username or not password:
            messages.error(request, 'Please provide both email/username and password.')
            return render(request, 'landing/login.html')
        
        # Try to authenticate by username first
        user = authenticate(request, username=email_or_username, password=password)
        
        # If that fails, try to find user by email and authenticate
        if not user:
            try:
                user_obj = User.objects.get(email=email_or_username)
                user = authenticate(request, username=user_obj.username, password=password)
            except User.DoesNotExist:
                user = None
        
        if user:
            login(request, user)
            
            # Handle next parameter for redirects
            next_url = request.POST.get('next') or request.GET.get('next')
            if next_url:
                return redirect(next_url)
            
            # Redirect based on user type
            if user.is_staff:
                messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
                return redirect('custom_admin:dashboard')
            else:
                messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
                return redirect('student_portal:dashboard')
        else:
            messages.error(request, 'Invalid email/username or password. Please try again.')
    
    return render(request, 'landing/login.html')


def courses(request):
    """Public courses listing page with categories"""
    courses = Course.objects.filter(
        is_published=True
    ).select_related('category').order_by('-created_at')
    
    categories = Category.objects.filter(
        courses__is_published=True
    ).distinct().order_by('name')
    
    context = {
        'courses': courses,
        'categories': categories,
    }
    return render(request, 'landing/courses.html', context)

def course_detail(request, course_id):
    """Public course detail page for enrollment"""
    course = get_object_or_404(
        Course, 
        id=course_id, 
        is_published=True, 
        allow_public_enrollment=True
    )
    
    # Check if user is already enrolled
    is_enrolled = False
    if request.user.is_authenticated:
        is_enrolled = Enrollment.objects.filter(
            user=request.user, 
            course=course, 
            active=True
        ).exists()
    
    context = {
        'course': course,
        'is_enrolled': is_enrolled,
        'razorpay_key': getattr(settings, 'RAZORPAY_KEY_ID', ''),
    }
    return render(request, 'landing/course_detail.html', context)

@login_required
def enroll_course(request, course_id):
    """Handle course enrollment with payment"""
    course = get_object_or_404(
        Course, 
        id=course_id, 
        is_published=True, 
        allow_public_enrollment=True
    )
    
    # Security check: prevent duplicate enrollments
    if Enrollment.objects.filter(user=request.user, course=course, active=True).exists():
        messages.warning(request, 'You are already enrolled in this course.')
        return redirect('landing:course_detail', course_id=course.id)
    
    if request.method == 'POST':
        if course.is_free_course:
            # Free course enrollment
            with transaction.atomic():
                enrollment = Enrollment.objects.create(
                    user=request.user,
                    course=course,
                    enrollment_type='individual',
                    total_amount=0,
                    tax_amount=0,
                    payment_status='free'
                )
                messages.success(request, f'Successfully enrolled in {course.title}!')
                return redirect('student_portal:dashboard')
        else:
            # Paid course - create Razorpay order
            try:
                # Initialize Razorpay client
                client = razorpay.Client(auth=(
                    getattr(settings, 'RAZORPAY_KEY_ID', ''),
                    getattr(settings, 'RAZORPAY_KEY_SECRET', '')
                ))
                
                # Convert amount to paisa (multiply by 100)
                amount_in_paisa = int(course.total_price * 100)
                
                # Create order
                order_data = {
                    'amount': amount_in_paisa,
                    'currency': 'INR',
                    'receipt': f'course_{course.id}_user_{request.user.id}',
                    'notes': {
                        'course_id': course.id,
                        'user_id': request.user.id,
                        'enrollment_type': 'individual'
                    }
                }
                
                razorpay_order = client.order.create(data=order_data)
                
                context = {
                    'course': course,
                    'razorpay_order_id': razorpay_order['id'],
                    'razorpay_key': getattr(settings, 'RAZORPAY_KEY_ID', ''),
                    'amount': amount_in_paisa,
                    'user_name': request.user.get_full_name() or request.user.username,
                    'user_email': request.user.email,
                }
                
                return render(request, 'landing/payment.html', context)
                
            except Exception as e:
                messages.error(request, f'Payment initialization failed: {str(e)}')
                return redirect('landing:course_detail', course_id=course.id)
    
    return redirect('landing:course_detail', course_id=course.id)

@csrf_exempt
@require_POST
def payment_success(request):
    """Handle successful payment callback from Razorpay"""
    try:
        # Get payment details from request
        payment_id = request.POST.get('razorpay_payment_id')
        order_id = request.POST.get('razorpay_order_id')
        signature = request.POST.get('razorpay_signature')
        
        if not all([payment_id, order_id, signature]):
            return HttpResponseBadRequest('Missing payment parameters')
        
        # Initialize Razorpay client
        client = razorpay.Client(auth=(
            getattr(settings, 'RAZORPAY_KEY_ID', ''),
            getattr(settings, 'RAZORPAY_KEY_SECRET', '')
        ))
        
        # Verify payment signature
        params_dict = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        
        try:
            client.utility.verify_payment_signature(params_dict)
        except razorpay.errors.SignatureVerificationError:
            return JsonResponse({'status': 'error', 'message': 'Invalid payment signature'})
        
        # Fetch order details to get course and user info
        order_details = client.order.fetch(order_id)
        course_id = order_details['notes']['course_id']
        user_id = order_details['notes']['user_id']
        
        # Get course and user objects
        course = get_object_or_404(Course, id=course_id)
        user = get_object_or_404(User, id=user_id)
        
        # Security check: prevent duplicate enrollments
        if Enrollment.objects.filter(user=user, course=course, active=True).exists():
            return JsonResponse({'status': 'error', 'message': 'Already enrolled'})
        
        # Create enrollment and payment records
        with transaction.atomic():
            enrollment = Enrollment.objects.create(
                user=user,
                course=course,
                enrollment_type='individual',
                total_amount=course.total_price,
                tax_amount=course.tax_amount,
                payment_status='completed'
            )
            
            payment = Payment.objects.create(
                enrollment=enrollment,
                installment_number=1,
                amount=course.total_price,
                tax_amount=course.tax_amount,
                payment_method='razorpay',
                transaction_id=payment_id,
                payment_date=timezone.now(),
                due_date=timezone.now().date(),
                status='completed',
                notes=f'Razorpay Order ID: {order_id}'
            )
        
        return JsonResponse({
            'status': 'success',
            'message': 'Payment successful! Enrollment completed.',
            'redirect_url': '/student/'  # Redirect to student portal
        })
        
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': f'Payment processing failed: {str(e)}'})

@csrf_exempt
@require_POST  
def payment_failed(request):
    """Handle failed payment callback from Razorpay"""
    try:
        error_data = json.loads(request.body)
        # Log the error for debugging
        print(f"Payment failed: {error_data}")
        
        return JsonResponse({
            'status': 'error',
            'message': 'Payment failed. Please try again.'
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': 'Payment processing error'})
